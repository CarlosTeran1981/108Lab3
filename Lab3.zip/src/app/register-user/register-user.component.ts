import { user} from './../models/user';
import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {

  model: user = new user ();
  passRetype: string = '';

  constructor( private data : DataService) { }

  ngOnInit() {
  }

  saveUser() {
    this.data.addUser(this.model);
    this.model = new user();
    this.passRetype = "";
    console.log(this.data.getAllUsers());
  }

}
